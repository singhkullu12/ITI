 <div class="row">
 	<div class="col-md-12 ">
		<div class="panel panel-white">
            <div class="panel-heading">
	            <i class="fa fa-external-link-square"></i>
								Time Scheduling :
	            <div class="panel-tools">										
					<div class="dropdown">
						<a data-toggle="dropdown" class="btn btn-xs dropdown-toggle btn-transparent-grey">
							<i class="fa fa-cog"></i>
						</a>
						<ul class="dropdown-menu dropdown-light pull-right" role="menu">
							<li>
								<a class="panel-collapse collapses" href="#"><i class="fa fa-angle-up"></i> <span>Collapse</span> </a>
							</li>
							<li>
								<a class="panel-refresh" href="#"> <i class="fa fa-refresh"></i> <span>Refresh</span> </a>
							</li>
							<li>
								<a class="panel-config" href="#panel-config" data-toggle="modal"> <i class="fa fa-wrench"></i> <span>Configurations</span></a>
							</li>
							<li>
								<a class="panel-expand" href="#"> <i class="fa fa-expand"></i> <span>Fullscreen</span></a>
							</li>										
						</ul>
					</div>
				</div>
        	</div>
<!-- ---------------------------------------------------- START BODY ---------------------------------------------------- -->
            <div class="row"> 
            	<div class="panel-body">
                    <div class="alert alert-info center">
                    Please Choose Number of Days to Schedule
                    </div>
                    	<div class="row" >	
                    	<div class="center">
                    					<input type='checkbox' id="monday" name='day[]' value="Monday">Monday
                                     	<input type='checkbox' id="tuesday" name='day[]' value="Tuesday">Tuesday
                                     	<input type='checkbox' id="wednesday" name='day[]' value="Wednesday">Wednesday
                                     	<input type='checkbox' id="thursday" name='day[]' value="Thursday">Thursday
                                     	<input type='checkbox' id="friday" name='day[]' value="Friday">Friday
                                     	<input type='checkbox' id="saturday" name='day[]' value="Saturday">Saturday 
                         </div></div>
                    </div>                                
            	</div>
          </div>
        </div>        
      </div>
      <div id="structperiod"></div>
                      
